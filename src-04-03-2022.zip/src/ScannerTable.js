import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import banner from './images/Bg.png';
import TrackChangesIcon from '@mui/icons-material/TrackChanges';
import DownloadIcon from '@mui/icons-material/Download';



export default function DataTable() {
  const [age, setAge] = React.useState('');
  const handleChangee = (event) => {
    setAge(event.target.value);
  };
   const [exchange, setexchangee] = React.useState('');
   const [pair, setpair] = React.useState('');
  const handleChangeone = (event) => {
    setexchangee(event.target.value);
  };
  const handleChangesec = (event) => {
    setpair(event.target.value);
  };
  return (
      <>
     <Grid container spacing={1}>
     <Grid item xs={2}>
    <h3  className='scannerbuttonheading'> <TrackChangesIcon />Scanner</h3>
      </Grid>
        <Grid item xs={8}>
       <Button variant="contained" spacing={2}>Trend</Button>
      <Button variant="contained">Price to MA</Button>
      <Button variant="contained">MA Cross</Button>
      <Button variant="contained">RSI</Button>
      <Button variant="contained">FSR</Button>
      <Button variant="contained">Stoch cross</Button>
      <Button variant="contained">Macd</Button>
      <Grid item xs={6}>
      <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
        <InputLabel id="demo-simple-select-standard-label">Select MA</InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={age}
          onChange={handleChangee}
          label="Age"
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
      <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
        <InputLabel id="demo-simple-select-standard-label">Select Cross Length</InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={age}
          onChange={handleChangee}
          label="Age"
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
        </Grid>
        </Grid>
        <Grid item xs={2}>
      <FormControl variant="standard" sx={{ m: 1, minWidth: 50 }}>
        <InputLabel id="demo-simple-select-standard-label">Pair</InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={age}
          onChange={handleChangee}
          label="Age"
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
      <FormControl variant="standard" sx={{ m: 1, minWidth: 50}}>
        <InputLabel id="demo-simple-select-standard-label">Exchange</InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={age}
          onChange={handleChangee}
          label="Age"
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
      <DownloadIcon />
      <DownloadIcon />
        </Grid>
      </Grid>
    
 
    </>
  );
}