import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Container from '@mui/material/Container';

function createData( pair,price, hour, volume) {
  return { pair, price, hour, volume };
}

const rows = [
  createData('XTZUSD', 12, 6.0, 24),
  createData('ADAUSD', 1.234, 9.0, 37),
  createData('ETHUSD', 2.912, 16.0, 24),
  createData('LINKUSD', 305, 3.7, 67),
];

export default function Topcoin() {
  return (
    <>
<Container>
<Grid container>
  <TableContainer component={Paper}>
  <h4 className='Tableheading'> TOP BULL COINS</h4>
      <Table aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>Pair</TableCell>
            <TableCell>Price</TableCell>
            <TableCell>%24HR</TableCell>
            <TableCell>Volume</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow
              key={row.pair}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.pair}
              </TableCell>
              <TableCell>{row.price}</TableCell>
              <TableCell>{row.hour}</TableCell>
              <TableCell>{row.volume}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
</Grid>
    </Container>
    </>
  );
}
