import * as React from 'react';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import banner from './images/Bg.png';
import Trend from './Trend';
import Topcoin from './Topcoin';
import Signal from './Signals';
import Paper from '@mui/material/Paper';

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

export default function Toptable() {
  return (
    <>
       <Grid container spacing={2}>
       <Grid item xs={12}>
          <img src={banner} width="100%" /></Grid>
        <Grid item xs={4}>
      <Paper><Topcoin /></Paper>
        </Grid>
        <Grid item xs={4}>
        <Paper><Trend /></Paper>
        </Grid>
        <Grid item xs={4}>
        <Paper> <Signal /></Paper>
        </Grid>
      </Grid>
     
    </>
  );
}
