import * as React from 'react';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';


export default function Scannerbutton() {
  const [value, setValue] = React.useState(2);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    
    <Grid container spacing={2}>
      <Grid item xs={12}>
    <h3 className='scannerbuttonheading'>Scanner</h3>
      </Grid>
    <Grid item xs={4}>
         <Tabs value={value} onChange={handleChange} aria-label="disabled tabs example">
      <Tab label="Standard" />
      <Tab label="Customize" />
      <Tab label="Profile" />
    </Tabs>
        </Grid>
      </Grid>
  );
}