import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Container } from '@mui/material';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import banner from './images/Bg.png';



const Item = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(1),
  textAlign: 'left',
  color: theme.palette.text.secondary,
}));


  const columns = [
    { field: 'sno', headerName: 'S.no' },
    { field: 'name', headerName: 'Name' },
    { field: 'm15', headerName: 'M15'},
    { field: 'h1', headerName: 'H1'},
    { field: 'h4', headerName: 'H4'},
    { field: 'h12', headerName: 'H12'},
    { field: 'd', headerName: 'D'},
    { field: 'w', headerName: 'W'},
    { field: 'price', headerName: 'Price'},
    { field: '24hr', headerName: '24Hr'},
    { field: 'volume', headerName: 'Volume'},
    { field: 'marketcap', headerName: 'Market Cap'},
    { field: 'linktv', headerName: 'Link TV'},
    
  ];
  
  const rows = [
    
  ];
  


export default function DataTable() {
   const [exchange, setexchangee] = React.useState('');
   const [pair, setpair] = React.useState('');
  const handleChange = (event) => {
    setexchangee(event.target.value);
  };
  const handleChangesec = (event) => {
    setpair(event.target.value);
  };
  return (
      <>
     <Grid container spacing={2}>
        <Grid item xs={12}>
       <Button variant="outlined">Trend</Button>
      <Button variant="outlined">Price to MA</Button>
      <Button variant="outlined">MA Cross</Button>
      <Button variant="outlined">RSI</Button>
      <Button variant="outlined">FSR</Button>
      <Button variant="outlined">Stoch cross</Button>
      <Button variant="outlined">Macd</Button>
        </Grid>
       
      </Grid>

      <Grid container spacing={2}>
      <Grid item xs={2}>
        <Item> <FormControl fullWidth>
        <InputLabel id="demo-simple-select-label">Exchange</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={exchange}
          label="Age"
          onChange={handleChange}
        >
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
        
      </FormControl></Item>
      </Grid>
      <Grid item xs={2}>
        <Item> <FormControl fullWidth>
        <InputLabel id="demo-simple-select-label">Pair</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={pair}
          label="Age"
          onChange={handleChangesec}
        >
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
        
      </FormControl></Item>
      </Grid>
    </Grid>    
    <Grid container spacing={2}>
      <Grid item xs={12}>
         
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[13]}
      />
    </div>
     
    </Grid>
    <Grid item xs={12}>
          <img src={banner} width="100%" /></Grid>
      </Grid>
      
    </>
  );
}